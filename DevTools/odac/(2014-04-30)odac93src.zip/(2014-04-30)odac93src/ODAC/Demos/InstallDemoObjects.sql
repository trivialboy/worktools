CREATE TABLE DEPT (
  DEPTNO NUMBER(2) CONSTRAINT PK_DEPT PRIMARY KEY,
  DNAME VARCHAR2(14) ,
  LOC VARCHAR2(13)
);

CREATE TABLE EMP (
  EMPNO NUMBER(4) CONSTRAINT PK_EMP PRIMARY KEY,
  ENAME VARCHAR2(10),
  JOB VARCHAR2(9),
  MGR NUMBER(4),
  HIREDATE DATE,
  SAL NUMBER(7,2),
  COMM NUMBER(7,2),
  DEPTNO NUMBER(2) CONSTRAINT FK_DEPTNO REFERENCES DEPT
);

CREATE TABLE ODAC_Loaded (
  Code NUMBER,
  Num NUMBER(10),
  Num1 NUMBER(5,2),
  Str VARCHAR2(50),
  Dat DATE
);

CREATE TABLE ODAC_Pictures (
  Name VARCHAR2(50),
  Picture LONG RAW
);

CREATE TABLE ODAC_Long (
  Code NUMBER PRIMARY KEY,
  Title VARCHAR2(30),
  Value LONG
);

CREATE TABLE ODAC_Long_char (
  Code NUMBER PRIMARY KEY,
  Title VARCHAR2(30),
  Value VARCHAR2(2000) -- 4000 for Oracle 8 or higher
);

CREATE TABLE ThreadTable (
  ID NUMBER,
  NAME VARCHAR2(30)
);

create or replace
package ODACPack
is
  TYPE TCursor IS REF CURSOR;
  procedure GetDept(Cur OUT TCursor);
  function GetDeptFunc return TCursor;
  procedure GetEmp(Cur OUT TCursor);
end;
/
create or replace
package body ODACPack
is
  procedure GetDept(Cur OUT TCursor)
  is
  begin
    OPEN Cur FOR
      SELECT *
      FROM Dept
      ORDER BY DeptNo;
  end; 
  function GetDeptFunc
    return TCursor
  is
    Cur TCursor;
  begin
    OPEN Cur FOR
      SELECT *
      FROM Dept
      ORDER BY DeptNo;
    return Cur;
  end; 
  procedure GetEmp(Cur OUT TCursor)
  is
  begin
    OPEN Cur FOR
      SELECT *
      FROM Emp
      ORDER BY EmpNo;
  end; 
end;
/

CREATE TABLE CRGRID_TEST (
  Id NUMBER(4) PRIMARY KEY,
  Name VARCHAR2(10),
  Country VARCHAR2(30),
  City VARCHAR2(30),
  Street VARCHAR2(30),
  BirthDate DATE,
  Job VARCHAR2(9),
  Hiredate DATE,
  Sal NUMBER(7, 2),
  Remarks LONG
);

CREATE TABLE ErrorMsg (
    ErrorCode INTEGER,
    Constraint VARCHAR(30),
    Message VARCHAR(50),
    SenderName VARCHAR(30),
    ErrorClass VARCHAR(20)
);

INSERT INTO DEPT VALUES
  (10,'ACCOUNTING','NEW YORK');
INSERT INTO DEPT VALUES
  (20,'RESEARCH','DALLAS');
INSERT INTO DEPT VALUES
  (30,'SALES','CHICAGO');
INSERT INTO DEPT VALUES
  (40,'OPERATIONS','BOSTON');

INSERT INTO EMP VALUES
  (7369,'SMITH','CLERK',7902,to_date('17-12-1980','dd-mm-yyyy'),800,NULL,20);
INSERT INTO EMP VALUES
  (7499,'ALLEN','SALESMAN',7698,to_date('20-02-1981','dd-mm-yyyy'),1600,300,30);
INSERT INTO EMP VALUES
  (7521,'WARD','SALESMAN',7698,to_date('22-02-1981','dd-mm-yyyy'),1250,500,30);
INSERT INTO EMP VALUES
  (7566,'JONES','MANAGER',7839,to_date('02-04-1981','dd-mm-yyyy'),2975,NULL,20);
INSERT INTO EMP VALUES
  (7654,'MARTIN','SALESMAN',7698,to_date('28-09-1981','dd-mm-yyyy'),1250,1400,30);
INSERT INTO EMP VALUES
  (7698,'BLAKE','MANAGER',7839,to_date('01-05-1981','dd-mm-yyyy'),2850,NULL,30);
INSERT INTO EMP VALUES
  (7782,'CLARK','MANAGER',7839,to_date('09-06-1981','dd-mm-yyyy'),2450,NULL,10);
INSERT INTO EMP VALUES
  (7788,'SCOTT','ANALYST',7566,to_date('13-07-87','dd-mm-yyyy'),3000,NULL,20);
INSERT INTO EMP VALUES
  (7839,'KING','PRESIDENT',NULL,to_date('17-11-1981','dd-mm-yyyy'),5000,NULL,10);
INSERT INTO EMP VALUES
  (7844,'TURNER','SALESMAN',7698,to_date('08-09-1981','dd-mm-yyyy'),1500,0,30);
INSERT INTO EMP VALUES
  (7876,'ADAMS','CLERK',7788,to_date('13-07-87','dd-mm-yyyy'),1100,NULL,20);
INSERT INTO EMP VALUES
  (7900,'JAMES','CLERK',7698,to_date('03-12-1981','dd-mm-yyyy'),950,NULL,30);
INSERT INTO EMP VALUES
  (7902,'FORD','ANALYST',7566,to_date('03-12-1981','dd-mm-yyyy'),3000,NULL,20);
INSERT INTO EMP VALUES
  (7934,'MILLER','CLERK',7782,to_date('23-01-1982','dd-mm-yyyy'),1300,NULL,10);

INSERT INTO ErrorMsg(ErrorCode, Constraint, Message) VALUES
  (955, '', 'Table ErrorMsg already exist');
INSERT INTO ErrorMsg(ErrorCode, Constraint, Message) VALUES
  (1438, '', 'DepNo must be < 100');
INSERT INTO ErrorMsg(ErrorCode, Constraint, Message) VALUES
  (2291, 'EMP_FOREIGN_KEY', 'Departament not exist');
INSERT INTO ErrorMsg(ErrorCode, Constraint, Message) VALUES
  (2291, '', 'Parent key not found');
INSERT INTO ErrorMsg(ErrorCode, Constraint, Message) VALUES
  (2292, 'EMP_FOREIGN_KEY', 'Can''t delete departament with employes');
INSERT INTO ErrorMsg(ErrorCode, Constraint, Message) VALUES
  (2292, '', 'Chield record found');

INSERT INTO CRGRID_TEST (Id, Name, Country, City, Street, BirthDate, Job, HireDate, Sal) VALUES
  (5001, 'SMITH', 'ENGLAND', 'LONDON', 'BOND st.', to_date('12.10.63', 'dd.mm.yy'), 'CLERK',
   to_date('17.12.80', 'dd.mm.yy'), 800);
INSERT INTO CRGRID_TEST (Id, Name, Country, City, Street, BirthDate, Job, HireDate, Sal) VALUES
  (5002, 'ALLEN', 'ENGLAND', 'LONDON', 'BAKER st.', to_date('04.03.61', 'dd.mm.yy'), 'SALESMAN',
   to_date('20.02.81', 'dd.mm.yy'), 1600);
INSERT INTO CRGRID_TEST (Id, Name, Country, City, Street, BirthDate, Job, HireDate, Sal) VALUES
  (5003, 'MARTIN', 'FRANCE', 'LION', 'WEAVER st.', to_date('23.01.57', 'dd.mm.yy'), 'MANAGER',
   to_date('02.04.81', 'dd.mm.yy'), 2900);

COMMIT;

-- Oracle 8 specific

CREATE TABLE ODAC_BFile (
  Code NUMBER PRIMARY KEY,
  Title VARCHAR2(30),
  Value BFile
);

CREATE TABLE ODAC_BLOB (
  ID NUMBER PRIMARY KEY,
  Title VARCHAR2(30),
  Pic BLOB
);

CREATE OR REPLACE
PROCEDURE ODAC_BLOB_Insert (
  p_ID NUMBER,
  p_Title VARCHAR2,
  p_Pic OUT BLOB
)
is
begin
  INSERT INTO ODAC_BLOB(ID, Title, Pic)
  VALUES (p_ID, p_Title, EMPTY_BLOB())
  RETURNING Pic
  INTO p_Pic;
end;
/

CREATE TABLE ODAC_Clob (
  Code NUMBER, -- PRIMARY KEY,
  Title VARCHAR2(30),
  Value CLOB
);

CREATE TYPE TODACArray1 AS VARRAY (5) OF NUMBER;

CREATE TYPE TODACArrType AS OBJECT (
  Num NUMBER,
  Str VARCHAR2(10)
);

CREATE TYPE TODACArray2 AS VARRAY (3) OF TODACArrType;

CREATE TYPE TODACArray3 AS VARRAY (4) OF CHAR(10);

CREATE TYPE TODACArrType1 AS OBJECT (
  Num NUMBER,
  Str VARCHAR2(10),
  Arr1 TODACArray1,
  Arr2 TODACArray3
);

CREATE TABLE ODAC_Array (
  Code NUMBER,
  Title VARCHAR2(10),
  Arr1 TODACArray1,
  Arr2 TODACArray2,
  Arr3 TODACArray3,
  Obj TODACArrType1
);

CREATE TYPE TODACNestedSubType AS OBJECT (
  Num NUMBER,
  Str VARCHAR2(10) 
);

CREATE TYPE TODACNestedType AS OBJECT (
  Num NUMBER,
  Str VARCHAR2(30),
  Obj TODACNestedSubType,
  Dat DATE
);

CREATE TYPE TODACNestedTable AS TABLE OF TODACNestedType; 

CREATE TABLE ODAC_NestedTable (
  Code NUMBER PRIMARY KEY,
  Content TODACNestedTable
)
NESTED TABLE Content STORE AS Content_Table;

CREATE TYPE TAddress AS OBJECT (
  Country VARCHAR2(30),
  City VARCHAR2(30),
  Street VARCHAR2(30),
  Apartment NUMBER
);

CREATE OR REPLACE
TYPE TPerson AS OBJECT (
  Name VARCHAR2(30),
  Address TAddress,
  Phone VARCHAR2(20),
  BirthDate DATE,

  MEMBER FUNCTION getName RETURN VARCHAR2,
  STATIC FUNCTION getClass RETURN VARCHAR2
);

CREATE OR REPLACE
TYPE BODY TPerson
as
  MEMBER FUNCTION getName RETURN VARCHAR2
  is
  begin
    return Name;
  end;

  STATIC FUNCTION getClass RETURN VARCHAR2
  is
  begin
    return 'TPerson';
  end;
end;
/

CREATE TYPE TRefObjectType AS OBJECT (
  Str VARCHAR2(30),
  Num NUMBER,
  Left REF TRefObjectType,
  Right REF TRefObjectType
);

CREATE TABLE ODAC_Ref OF TRefObjectType;

CREATE TABLE ODAC_Emp (
  Person TPerson,
  Job VARCHAR2(9),
  HireDate DATE,
  Sal NUMBER(7,2)
);

INSERT INTO ODAC_Array (Code, Title, Arr1, Arr2, Arr3, Obj) VALUES
  (1, 'Title 1', TODACArray1(1,2,3), TODACArray2(TODACArrType(12, 'Name1'), NULL, TODACArrType(89, 'BBB')), TODACArray3('AAA','BBB','CCC'), TODACArrType1(56, 'RRR', TODACArray1(1, NULL, 454, NULL, 657), TODACArray3(NULL, 'TTT', NULL, 'UUU')));
INSERT INTO ODAC_Array (Code, Title, Arr1, Arr2, Arr3, Obj) VALUES
  (2, 'Title 2', TODACArray1(21,NULL,23,24), TODACArray2(NULL, TODACArrType(124, 'GGGG'), NULL), TODACArray3(NULL,'WWW'), TODACArrType1(56, 'RRR', NULL, NULL));
INSERT INTO ODAC_Array (Code, Title, Arr1, Arr2, Arr3, Obj) VALUES
  (3, 'Title 3', TODACArray1(NULL,NULL,33,34,35), NULL, TODACArray3(NULL,'EEEE'), TODACArrType1(NULL, NULL, TODACArray1(1, NULL, 454, NULL, 657), TODACArray3(NULL, NULL, 'CCCC')));
INSERT INTO ODAC_Array (Code, Title, Arr1, Arr2, Arr3, Obj) VALUES
  (4, 'Title 4', NULL, NULL, NULL, NULL);

INSERT INTO ODAC_NestedTable (Code, Content) VALUES
  (1, TODACNestedTable(TODACNestedType(111, 'AAAAA', TODACNestedSubType(44, 'YYY'), NULL)));
INSERT INTO ODAC_NestedTable (Code, Content) VALUES
  (2, TODACNestedTable(TODACNestedType(22, 'BBB', TODACNestedSubType(456, 'UUU'), NULL),
   TODACNestedType(333, 'TTT', TODACNestedSubType(234, 'SSSSS'), NULL)));

INSERT INTO ODAC_Emp (Person, Job, HireDate, Sal) VALUES
  (TPerson('SMITH', TAddress('UK', 'London', 'Street', 12), '4677676', To_Date('12.06.68', 'dd.mm.yy')), 'CLERK', To_Date('06.07.85', 'dd.mm.yy'), 800);
INSERT INTO ODAC_Emp (Person, Job, HireDate, Sal) VALUES
  (TPerson('JONES', TAddress('USA', 'New York', 'Street', 418), '5689676', To_Date('19.07.65', 'dd.mm.yy')), 'MANAGER', To_Date('23.10.95', 'dd.mm.yy'), 1600);
INSERT INTO ODAC_Emp (Person, Job, HireDate, Sal) VALUES
  (TPerson('SCOTT', TAddress('UK', 'London', 'Street', 26), '8990453', To_Date('01.01.70', 'dd.mm.yy')), 'PRESIDENT', To_Date('16.02.81', 'dd.mm.yy'), 5000);
INSERT INTO ODAC_Emp (Person, Job, HireDate, Sal) vALUES
  (TPerson('MARTIN', TAddress('France', 'Paris', 'Street', 162), '14557988', To_Date('12.01.72', 'dd.mm.yy')), 'ANALYST', To_Date('16.02.90', 'dd.mm.yy'), 2300);

INSERT INTO ODAC_Ref (Str,Num) VALUES
  ('Left', 1);
INSERT INTO ODAC_Ref (Str,Num) VALUES
  ('Right', 2);
INSERT INTO ODAC_Ref (Str,Num,Left,Right) VALUES
  ('Root', 0, (select ref(a) from ODAC_ref a where num = 1),(select ref(a) from ODAC_ref a where num = 2));

COMMIT;

-- Oracle 9 specific

declare
doc varchar2(2000) :=
'<schema targetNamespace="http://www.oracle.com/PO.xsd"
  xmlns:po="http://www.oracle.com/PO.xsd"
  xmlns="http://www.w3.org/2001/XMLSchema">
  <complexType name="PurchaseOrderType">
    <sequence>
      <element name="PONum" type="decimal"/>

      <element name="Company">
        <simpleType>
          <restriction base="string">
            <maxLength value="100"/>
          </restriction>
        </simpleType>
      </element>

      <element name="Item" maxOccurs="1000">
        <complexType>
          <sequence>
            <element name="Part">
              <simpleType>
                <restriction base="string">
                  <maxLength value="1000"/>
                </restriction>
              </simpleType>
            </element>

            <element name="Price" type="float"/>

          </sequence>
        </complexType>
      </element>

    </sequence>
  </complexType>
  <element name="PurchaseOrder" type="po:PurchaseOrderType"/>
</schema>';
begin
  dbms_xmlschema.registerSchema('http://www.oracle.com/PO.xsd', doc);
end;
/

CREATE TABLE xmlschema_type (
  ID NUMBER PRIMARY KEY,
  XMLField SYS.XMLType
)
XMLTYPE COLUMN XMLField
  XMLSCHEMA "http://www.oracle.com/PO.xsd"
  ELEMENT "PurchaseOrder";

CREATE TABLE xml_type (
  ID NUMBER PRIMARY KEY,
  XMLField XMLTYPE
);

INSERT INTO xmlschema_type VALUES(
  1,
  XMLTYPE('<PurchaseOrder 
xmlns="http://www.oracle.com/PO.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.oracle.com/PO.xsd http://www.oracle.com/PO.xsd">
  <PONum>73</PONum>
  <Company>Oracle Corp</Company>
  <Item>
    <Part>9i Doc Set</Part>
    <Price>130</Price>
  </Item>
  <Item>
    <Part>8i Doc Set</Part>
    <Price>946</Price>
  </Item>
</PurchaseOrder>'
  )
);

INSERT INTO xml_type VALUES(
  1,
  XMLTYPE('<PurchaseOrder>
  <PONum>73</PONum>
  <Company>Oracle Corp</Company>
  <Item>
    <Part>9i Doc Set</Part>
    <Price>130</Price>
  </Item>
  <Item>
    <Part>8i Doc Set</Part>
    <Price>946</Price>
  </Item>
</PurchaseOrder>'
  )
);

INSERT INTO xml_type VALUES(
  2,
  XMLTYPE(
    '<root>value</root>'
  )
);

COMMIT;

begin
  dbms_aqadm.create_queue_table('qt_odac_raw', 'RAW');
end;
/

begin
  dbms_aqadm.create_queue('qu_odac_raw', 'qt_odac_raw');
end;
/

begin
  dbms_aqadm.start_queue('qu_odac_raw');
end;
/

create type obj_odac_dept as object
(
  DeptNo integer,
  DeptName varchar(100)
);

begin
  dbms_aqadm.create_queue_table('qt_odac_dept', 'obj_odac_dept');
end;
/

begin
  dbms_aqadm.create_queue('qu_odac_dept', 'qt_odac_dept');
end;
/

begin
  dbms_aqadm.start_queue('qu_odac_dept');
end;
/
