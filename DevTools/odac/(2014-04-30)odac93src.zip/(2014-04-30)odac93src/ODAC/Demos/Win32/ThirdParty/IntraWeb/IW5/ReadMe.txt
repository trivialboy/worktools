Oracle Data Access Components
Copyright 1997-2014, Devart. All Rights Reserved
--------------------------------------------------

Demo for IntraWeb included in ODAC was built and tested using
IntraWeb 5 for Delphi 7.

IMPORTANT NOTE:
  Demo is provided "as is", and there is no warranty that it is fully
  compatible with other versions of IntraWeb.