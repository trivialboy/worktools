DB Access Components
Copyright 1997-2014, Devart. All Rights Reserved
--------------------------------------------------

Demonstrates working with the TVirtualTable component. This sample shows
how to fill a virtual dataset with data from other datasets, filter data by
a given criteria, locate specified records, perform file operations, and
change data and table structure. This is one of the two demo projects for
C++Builder.
