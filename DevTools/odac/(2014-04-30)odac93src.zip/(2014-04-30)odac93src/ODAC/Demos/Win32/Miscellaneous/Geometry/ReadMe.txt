Oracle Data Access Components
Copyright 1997-2014, Devart. All Rights Reserved
--------------------------------------------------

Demonstrates using the SDO_GEOMETRY Oracle type with ODAC. This project reads
SDO_GEOMETRY objects from the database and draws figures stored in these
objects. The project allows you to edit figures and save them to the database.
