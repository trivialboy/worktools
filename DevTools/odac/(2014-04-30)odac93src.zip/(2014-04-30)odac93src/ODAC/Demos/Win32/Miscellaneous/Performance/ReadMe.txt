Oracle Data Access Components
Copyright 1997-2014, Devart. All Rights Reserved
--------------------------------------------------

Measures ODAC performance on several types of queries. This project lets
you compare ODAC performance to BDE, ADO, and dbExpress. Tests the
following functionality: Fetch, Master/Detail, Stored Procedure Call,
Data Loading, Multi Executing, and Insert/Post.
