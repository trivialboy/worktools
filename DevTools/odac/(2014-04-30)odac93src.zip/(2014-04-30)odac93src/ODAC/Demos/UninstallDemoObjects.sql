DROP PACKAGE ODACPack;
DROP TABLE EMP;
DROP TABLE DEPT;
DROP TABLE ODAC_Loaded;
DROP TABLE ODAC_Pictures;
DROP TABLE ODAC_Long;
DROP TABLE ODAC_Long_char;
DROP TABLE ThreadTable;
DROP TABLE CRGRID_TEST;
DROP TABLE ErrorMsg;


-- Oracle 8 specific

DROP TABLE ODAC_BFile;
DROP PROCEDURE ODAC_BLOB_Insert;
DROP TABLE ODAC_BLOB;
DROP TABLE ODAC_Clob;

DROP TABLE ODAC_Array;
DROP TYPE TODACArrType1;
DROP TYPE TODACArray3;
DROP TYPE TODACArray2;
DROP TYPE TODACArrType;
DROP TYPE TODACArray1;

DROP TABLE ODAC_NestedTable;
DROP TYPE TODACNestedTable; 
DROP TYPE TODACNestedType;
DROP TYPE TODACNestedSubType;


DROP TABLE ODAC_Emp;
DROP TYPE TPerson;
DROP TYPE TAddress;

DROP TABLE ODAC_Ref;
DROP TYPE TRefObjectType;


-- Oracle 9 specific

DROP TABLE xml_type;

DROP TABLE xmlschema_type;

begin
  dbms_aqadm.stop_queue('qu_odac_raw');
end;
/

begin
  dbms_aqadm.drop_queue('qu_odac_raw');
end;
/

begin
  dbms_aqadm.drop_queue_table('qt_odac_raw');
end;
/

begin
  dbms_aqadm.stop_queue('qu_odac_dept');
end;
/

begin
  dbms_aqadm.drop_queue('qu_odac_dept');
end;
/

begin
  dbms_aqadm.drop_queue_table('qt_odac_dept');
end;
/

drop type obj_odac_dept;
