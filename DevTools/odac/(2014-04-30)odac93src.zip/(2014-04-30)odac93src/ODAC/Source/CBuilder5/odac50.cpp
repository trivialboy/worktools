
//////////////////////////////////////////////////
//  Oracle Data Access Components
//  Copyright � 1998-2014 Devart. All right reserved.
//  ODAC Package for C++ Builder 5
//////////////////////////////////////////////////

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEUNIT("..\Ora.pas");
USEUNIT("..\OraSmart.pas");
USEUNIT("..\OraScript.pas");
USEUNIT("..\OraAlerter.pas");
USEUNIT("..\OraLoader.pas");
USEUNIT("..\OraErrHand.pas");
USEUNIT("..\OraSQLMonitor.pas");
USEUNIT("..\OraAQ.pas");
USEUNIT("..\OraTransaction.pas");
USERES("odac50.res");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("vcldb50.bpi");
USEPACKAGE("vclbde50.bpi");
USEPACKAGE("dac50.bpi");
USEUNIT("..\OraPackage.pas");
USEUNIT("..\OdacVcl.pas");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}
//---------------------------------------------------------------------------
