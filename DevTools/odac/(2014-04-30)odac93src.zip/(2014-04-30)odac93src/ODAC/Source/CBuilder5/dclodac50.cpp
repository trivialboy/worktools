
//////////////////////////////////////////////////
//  Oracle Data Access Components
//  Copyright � 1998-2014 Devart. All right reserved.
//  ODAC Package for C++ Builder 5
//////////////////////////////////////////////////

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEUNIT("..\Design\OraReg.pas");
USEUNIT("..\Design\OraDesign.pas");
USERES("dclodac50.res");
USEPACKAGE("odac50.bpi");
USEPACKAGE("dcldb50.bpi");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("vcldb50.bpi");
USEPACKAGE("vclbde50.bpi");
USEPACKAGE("dcldac50.bpi");
USEPACKAGE("vcljpg50.bpi");
USEUNIT("..\Design\OdacMenu.pas");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}
//---------------------------------------------------------------------------
