
//////////////////////////////////////////////////
//  Oracle Data Access Components
//  Copyright � 1998-2014 Devart. All right reserved.
//  OraProvider package
//////////////////////////////////////////////////

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEUNIT("..\OraProvider.pas");
USERES("oraprov50.res");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("vcldb50.bpi");
USEPACKAGE("vclmid50.bpi");
USEPACKAGE("odac50.bpi");
USEPACKAGE("Vclbde50.bpi");
USEPACKAGE("DAC50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
