
//////////////////////////////////////////////////
//  Oracle Data Access Components
//  Copyright � 1998-2014 Devart. All right reserved.
//  OraProvider package
//////////////////////////////////////////////////

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USEUNIT("..\Design\OraProviderReg.pas");
USERES("dcloraprov50.res");
USEPACKAGE("oraprov.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
