﻿// CodeGear C++Builder
// Copyright (c) 1995, 2013 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'OraNet.pas' rev: 26.00 (Windows)

#ifndef OranetHPP
#define OranetHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.Classes.hpp>	// Pascal unit
#include <System.SysUtils.hpp>	// Pascal unit
#include <System.DateUtils.hpp>	// Pascal unit
#include <CLRClasses.hpp>	// Pascal unit
#include <System.Win.ScktComp.hpp>	// Pascal unit
#include <Winapi.WinSock.hpp>	// Pascal unit
#include <Winapi.Windows.hpp>	// Pascal unit
#include <System.RTLConsts.hpp>	// Pascal unit
#include <CRTypes.hpp>	// Pascal unit
#include <CRFunctions.hpp>	// Pascal unit
#include <CRParser.hpp>	// Pascal unit
#include <CRVio.hpp>	// Pascal unit
#include <CRVioTcp.hpp>	// Pascal unit
#include <MemUtils.hpp>	// Pascal unit
#include <OraCall.hpp>	// Pascal unit
#include <OraParser.hpp>	// Pascal unit
#include <OraNumber.hpp>	// Pascal unit
#include <OraDateTime.hpp>	// Pascal unit
#include <OraInterval.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oranet
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS N_1;
class PASCALIMPLEMENTATION N_1 : public Clrclasses::Encoding
{
	typedef Clrclasses::Encoding inherited;
	
private:
	bool N_2;
	
protected:
	int __fastcall InternalGetBytes(System::WideChar * Chars, int CharIndex, int N_3, System::DynamicArray<System::Byte> &Bytes, int ByteIndex, int ByteCount);
	int __fastcall InternalGetChars(const System::DynamicArray<System::Byte> Bytes, int ByteIndex, int ByteCount, System::WideChar * Chars, int CharIndex, int N_3);
	
public:
	__fastcall N_1(void);
	virtual int __fastcall GetMaxByteCount(int N_3);
	virtual int __fastcall GetMaxCharCount(int byteCount);
	int __fastcall GetByteCount(System::WideChar *chars, const int chars_Size, int index, int count);
	int __fastcall GetCharCount(System::DynamicArray<System::Byte> bytes, int index, int count);
	virtual System::DynamicArray<System::Byte> __fastcall GetBytes(const System::AnsiString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::AnsiString chars, int charIndex, int N_3, System::DynamicArray<System::Byte> &bytes, int byteIndex)/* overload */;
	virtual System::DynamicArray<System::Byte> __fastcall GetBytes(const System::WideString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::WideString chars, int charIndex, int N_3, System::DynamicArray<System::Byte> &bytes, int byteIndex)/* overload */;
	virtual System::WideString __fastcall GetWideString(const System::DynamicArray<System::Byte> bytes, int index, int count)/* overload */;
	__classmethod N_1* __fastcall N_4();
public:
	/* TObject.Destroy */ inline __fastcall virtual ~N_1(void) { }
	
/* Hoisted overloads: */
	
public:
	inline System::WideString __fastcall  GetWideString(const System::DynamicArray<System::Byte> bytes){ return Clrclasses::Encoding::GetWideString(bytes); }
	
};


//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE bool UseDirectLobs;
extern DELPHI_PACKAGE int SDU;
extern DELPHI_PACKAGE int TDU;
extern DELPHI_PACKAGE int __cdecl OCIEnvCreate_(void * &envhpp, unsigned mode, const void * ctxp, const void * malocfp, const void * ralocfp, const void * mfreefp, NativeUInt xtramemsz, void * usrmempp);
extern DELPHI_PACKAGE int __cdecl OCIErrorGet_(void * hndlp, unsigned recordno, void * sqlstate, int &errcodep, void * N_30, unsigned bufsiz, unsigned htype);
extern DELPHI_PACKAGE int __cdecl OCIHandleAlloc_(void * parenth, void * &hndlpp, unsigned htype, NativeUInt xtramem_sz, void * usrmempp);
extern DELPHI_PACKAGE int __cdecl OCIHandleFree_(void * hndlp, unsigned htype);
extern DELPHI_PACKAGE int __cdecl OCIDescriptorAlloc_(void * parenth, void * &descpp, unsigned dtype, NativeUInt xtramem_sz, void * usrmempp);
extern DELPHI_PACKAGE int __cdecl OCIDescriptorFree_(void * descp, unsigned dtype);
extern DELPHI_PACKAGE int __cdecl OCIAttrGet_(void * trgthndlp, unsigned trghndltyp, void * N_5, Oracall::pub4 N_6, unsigned N_7, void * N_8);
extern DELPHI_PACKAGE int __cdecl OCIAttrGet2_(void * trgthndlp, unsigned trghndltyp, int &N_5, Oracall::pub4 N_6, unsigned N_7, void * N_8);
extern DELPHI_PACKAGE int __cdecl OCIAttrSet_(void * trgthndlp, unsigned trghndltyp, void * N_5, unsigned size, unsigned N_7, void * N_8);
extern DELPHI_PACKAGE int __cdecl OCIAttrSet2_(void * trgthndlp, unsigned trghndltyp, int &N_5, unsigned size, unsigned N_7, void * N_8);
extern DELPHI_PACKAGE int __cdecl OCIParamGet_(void * hndlp, unsigned htype, void * N_8, void * &N_31, unsigned pos);
extern DELPHI_PACKAGE int __cdecl OCIServerAttach_(void * srvhp, void * N_8, void * N_33, int dblink_len, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCIServerDetach_(void * srvhp, void * N_8, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCISessionBegin_(void * N_32, void * N_8, void * usrhp, unsigned N_36, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCISessionEnd_(void * N_32, void * N_8, void * usrhp, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCIServerVersion_(void * hndlp, void * N_8, void * N_30, unsigned N_34, System::Byte N_35);
extern DELPHI_PACKAGE int __cdecl OCIBreak_(void * hndlp, void * N_8);
extern DELPHI_PACKAGE int __cdecl OCIPasswordChange_(void * N_32, void * N_8, const void * user_name, unsigned usernm_len, const void * opasswd, unsigned opasswd_len, const void * npasswd, int npasswd_len, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCITransCommit_(void * N_32, void * N_8, unsigned flags);
extern DELPHI_PACKAGE int __cdecl OCITransRollback_(void * N_32, void * N_8, unsigned flags);
extern DELPHI_PACKAGE int __cdecl OCIStmtExecute_(void * N_32, void * stmtp, void * N_8, unsigned N_37, unsigned rowoff, void * snap_in, void * snap_out, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCIStmtFetch_(void * stmtp, void * N_8, unsigned N_38, System::Word orientation, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCIStmtPrepare_(void * stmtp, void * N_8, void * N_39, unsigned stmt_len, unsigned language, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCIStmtPrepare2_(void * N_32, void * &stmtp, void * N_8, void * N_39, unsigned stmt_len, void * key, unsigned key_len, unsigned language, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCIBindByName_(void * stmtp, void * &N_12, void * N_8, void * N_13, int N_14, void * N_15, int N_16, System::Word N_17, void * N_18, Oracall::pub2 N_19, Oracall::pub2 rcodep, unsigned N_20, Oracall::pub4 N_21, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCIBindByPos_(void * stmtp, void * &N_12, void * N_8, unsigned N_26, void * N_15, int N_16, System::Word N_17, void * N_18, Oracall::pub2 N_19, Oracall::pub2 rcodep, unsigned N_20, Oracall::pub4 N_21, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCIBindArrayOfStruct_(void * bindp, void * N_8, unsigned N_9, unsigned N_10, unsigned N_11, unsigned rcskip);
extern DELPHI_PACKAGE int __cdecl OCIBindDynamic_(void * bindp, void * N_8, void * N_22, void * N_23, void * N_24, void * N_25);
extern DELPHI_PACKAGE int __cdecl OCIDefineByPos_(void * stmtp, void * &N_28, void * N_8, unsigned N_26, void * N_15, int N_16, System::Word N_17, void * N_18, Oracall::pub2 N_29, Oracall::pub2 rcodep, unsigned mode);
extern DELPHI_PACKAGE int __cdecl OCIDefineArrayOfStruct_(void * defnp, void * N_8, unsigned N_9, unsigned N_10, unsigned N_27, unsigned rcskip);
extern DELPHI_PACKAGE int __cdecl OCIDefineDynamic_(void * defnp, void * N_8, void * N_24, void * N_25);
extern DELPHI_PACKAGE int __cdecl OCILobCharSetForm_(void * N_40, void * N_8, const void * locp, System::Byte &N_41);
extern DELPHI_PACKAGE int __cdecl OCILobGetLength_(void * N_32, void * N_8, void * locp, unsigned &N_42);
extern DELPHI_PACKAGE int __cdecl OCILobCreateTemporary_(void * N_32, void * N_8, void * locp, System::Word N_43, System::Byte N_41, System::Byte lobtype, int cache, System::Word duration);
extern DELPHI_PACKAGE int __cdecl OCILobFreeTemporary_(void * N_32, void * N_8, void * locp);
extern DELPHI_PACKAGE int __cdecl OCILobIsTemporary_(void * N_40, void * N_8, void * locp, BOOL &is_temporary);
extern DELPHI_PACKAGE int __cdecl OCILobLocatorIsInit_(void * N_40, void * N_8, const void * locp, int &N_44);
extern DELPHI_PACKAGE int __cdecl OCILobRead_(void * N_32, void * N_8, void * locp, unsigned &N_45, unsigned N_46, void * N_30, unsigned N_47, void * ctxp, void * cbfp, System::Word N_43, System::Byte N_41);
extern DELPHI_PACKAGE int __cdecl OCILobTrim_(void * N_32, void * N_8, void * locp, unsigned newlen);
extern DELPHI_PACKAGE int __cdecl OCILobWrite_(void * N_32, void * N_8, void * locp, unsigned &N_45, unsigned N_46, void * N_30, unsigned N_47, System::Byte N_48, void * ctxp, void * cbfp, System::Word N_43, System::Byte N_41);
extern DELPHI_PACKAGE int __cdecl OCINumberAssign_(void * err, const void * from, void * tonum);
extern DELPHI_PACKAGE int __cdecl OCINumberCmp_(void * err, const void * number1, const void * number2, int &res);
extern DELPHI_PACKAGE int __cdecl OCINumberFromInt_(void * err, __int64 &inum, unsigned inum_length, unsigned inum_s_flag, void * number);
extern DELPHI_PACKAGE int __cdecl OCINumberFromReal_(void * err, double &rnum, unsigned rnum_length, void * number);
extern DELPHI_PACKAGE int __cdecl OCINumberFromText_(void * err, const void * str, unsigned str_length, const void * fmt, unsigned fmt_length, const void * nls_params, unsigned nls_p_length, void * number);
extern DELPHI_PACKAGE int __cdecl OCINumberToInt_(void * err, void * number, unsigned rsl_length, unsigned rsl_flag, __int64 &rsl);
extern DELPHI_PACKAGE int __cdecl OCINumberToReal_(void * err, const void * number, unsigned rsl_length, double &rsl);
extern DELPHI_PACKAGE int __cdecl OCINumberToText_(void * err, void * number, const void * fmt, unsigned fmt_length, const void * nls_params, unsigned nls_p_length, unsigned &buf_size, void * N_49);
extern DELPHI_PACKAGE int __cdecl OCINumberFromBCD_(void * err, System::DynamicArray<System::Byte> rnum, unsigned rnum_length, void * number);
extern DELPHI_PACKAGE int __cdecl OCINumberToBCD_(void * err, const void * number, unsigned rsl_length, void *rsl);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeAssign_(void * hndl, void * err, void * src, void * dst);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeCheck_(void * hndl, void * err, void * date, unsigned &valid);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeCompare_(void * hndl, void * err, const void * date1, const void * date2, int &res);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeConstruct_(void * hndl, void * err, void * datetime, short year, System::Byte month, System::Byte day, System::Byte hour, System::Byte min, System::Byte sec, unsigned fsec, void * timezone, int timezone_length);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeFromText_(void * hndl, void * err, void * date_str, int d_str_length, void * fmt, System::Byte fmt_length, void * lang_name, int lang_length, void * date);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeToText_(void * hndl, void * err, void * date, void * fmt, System::Byte fmt_length, System::Byte fsprec, void * lang_name, int lang_length, unsigned &buf_size, void * N_49);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeGetDate_(void * hndl, void * err, void * date, short &year, System::Byte &month, System::Byte &day);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeGetTime_(void * hndl, void * err, void * datetime, System::Byte &hour, System::Byte &minute, System::Byte &sec, unsigned &fsec);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeGetTimeZoneOffset_(void * hndl, void * err, void * datetime, System::Int8 &hour, System::Int8 &minute);
extern DELPHI_PACKAGE int __cdecl OCIDateTimeGetTimeZoneName_(void * hndl, void * err, void * datetime, Oracall::pub1 N_49, unsigned &N_50);
extern DELPHI_PACKAGE int __cdecl OCIIntervalAssign_(void * hndl, void * err, void * ininter, void * outinter);
extern DELPHI_PACKAGE int __cdecl OCIIntervalCheck_(void * hndl, void * err, void * inter, unsigned &valid);
extern DELPHI_PACKAGE int __cdecl OCIIntervalCompare_(void * hndl, void * err, void * inter1, void * inter2, int &res);
extern DELPHI_PACKAGE int __cdecl OCIIntervalFromText_(void * hndl, void * err, void * inpstr, int str_len, void * res);
extern DELPHI_PACKAGE int __cdecl OCIIntervalToText_(void * hndl, void * err, void * inter, System::Byte lfprec, System::Byte fsprec, void * buffer, NativeUInt N_50, NativeUInt &resultlen);
extern DELPHI_PACKAGE int __cdecl OCIIntervalSetYearMonth_(void * hndl, void * err, int yr, int mnth, void * res);
extern DELPHI_PACKAGE int __cdecl OCIIntervalGetYearMonth_(void * hndl, void * err, int &yr, int &mnth, void * res);
extern DELPHI_PACKAGE int __cdecl OCIIntervalSetDaySecond_(void * hndl, void * err, int dy, int hr, int mm, int ss, int fsec, void * res);
extern DELPHI_PACKAGE int __cdecl OCIIntervalGetDaySecond_(void * hndl, void * err, int &dy, int &hr, int &mm, int &ss, int &fsec, void * res);
extern DELPHI_PACKAGE int __cdecl OCIIntervalFromNumber_(void * hndl, void * err, void * interval, void * number);
extern DELPHI_PACKAGE int __cdecl OCIRowidToChar_(void * rowidDesc, void * outbfp, System::Word &outbflp, void * N_8);
}	/* namespace Oranet */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_ORANET)
using namespace Oranet;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OranetHPP
